"use client";

import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ChevronRight, ChevronLeft } from "lucide-react";

const productsPerPage = 12;

const AllProductsPage = () => {
  /* ================================
     FILTER STATES
  =================================*/
  const [search, setSearch] = useState("");
  const [priceMin, setPriceMin] = useState("");
  const [priceMax, setPriceMax] = useState("");
  const [sortOption, setSortOption] = useState("default");

  /* ================================
     PAGINATION (THEO BE)
  =================================*/
  const [currentPage, setCurrentPage] = useState(1);
  const [pagination, setPagination] = useState(null);

  /* ================================
     API DATA
  =================================*/
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);

  /* ================================
     FETCH LISTINGS TỪ BE
  =================================*/
  useEffect(() => {
    let isMounted = true;

    async function fetchListings() {
      try {
        setLoading(true);

        const res = await listingApi.getAll({
          page: currentPage,
          limit: productsPerPage,
          search: search || undefined,
        });

        if (res && res.status === "success" && Array.isArray(res.data)) {
          // Map dữ liệu từ Listing model (có kèm store)
          let mapped = res.data.map((item) => {
            const priceNumber = item.price ? Number(item.price) : 0;

            // Lấy slug công ty từ quan hệ store
            const companySlug =
              (item.store && (item.store.slug || item.store.id)) || item.store_slug || "company";

            return {
              id: item.id,
              companySlug,
              name: item.title || item.name || "Không có tên",
              // BE chưa có cột ảnh riêng cho Listing, có thể lưu trong meta sau này
              image:
                (item.meta && item.meta.thumbnail_url) ||
                item.thumbnail ||
                item.image ||
                "/placeholder.png",
              priceValue: isNaN(priceNumber) ? 0 : priceNumber,
              priceLabel: item.price
                ? `${Number(item.price).toLocaleString("vi-VN")} đ`
                : item.price_label || "Liên hệ",
              createdAt: item.created_at,
            };
          });

          // Lọc giá trên FE
          if (priceMin) {
            mapped = mapped.filter((p) => p.priceValue >= Number(priceMin));
          }
          if (priceMax) {
            mapped = mapped.filter((p) => p.priceValue <= Number(priceMax));
          }

          // Sắp xếp trên FE
          if (sortOption === "low") {
            mapped.sort((a, b) => a.priceValue - b.priceValue);
          } else if (sortOption === "high") {
            mapped.sort((a, b) => b.priceValue - a.priceValue);
          } else if (sortOption === "newest") {
            mapped.sort((a, b) => {
              if (!a.createdAt || !b.createdAt) return b.id - a.id;
              return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
            });
          }

          if (isMounted) {
            setListings(mapped);
            setPagination(
              res.pagination || {
                current_page: currentPage,
                per_page: productsPerPage,
                total: mapped.length,
                last_page: 1,
              }
            );
          }
        }
      } catch (err) {
        console.error("Không thể tải danh sách sản phẩm:", err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    fetchListings();

    return () => {
      isMounted = false;
    };
  }, [currentPage, search, priceMin, priceMax, sortOption]);

  /* Reset page khi đổi filter (để không bị giữ page cũ > last_page) */
  useEffect(() => {
    setCurrentPage(1);
  }, [search, priceMin, priceMax, sortOption]);

  /* ================================
      PAGINATION UI
  =================================*/
  const totalPages = (pagination && pagination.last_page) || 1;
  const totalItems =
    (pagination && typeof pagination.total === "number" && pagination.total) || listings.length;

  const generatePages = () => {
    const pages = [];
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      pages.push(1, 2, 3, "...", totalPages);
    }
    return pages;
  };

  const pageList = generatePages();

  return (
    <div className="min-h-screen bg-white pt-6 px-4 md:px-8">
      {/* BREADCRUMB */}
      <nav className="flex items-center text-sm text-gray-600 mb-4">
        <Link to="/" className="hover:text-blue-600">
          Trang chủ
        </Link>
        <ChevronRight size={16} className="mx-2" />
        <span className="font-semibold text-gray-900">Tất cả sản phẩm</span>
      </nav>

      <h1 className="text-3xl font-bold mb-6 text-gray-900">Tất cả sản phẩm ({totalItems})</h1>

      {/* LOADING */}
      {loading && <p className="italic text-gray-500 mb-6">Đang tải sản phẩm...</p>}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* ========== FILTER SIDEBAR ========== */}
        <aside className="md:col-span-1">
          <div className="bg-white rounded-2xl border shadow p-5 space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-lg text-gray-900">Bộ lọc</h3>
              <button
                onClick={() => {
                  setSearch("");
                  setPriceMin("");
                  setPriceMax("");
                  setSortOption("default");
                }}
                className="text-blue-600 text-sm hover:underline"
              >
                Xóa lọc
              </button>
            </div>

            {/* SEARCH */}
            <div>
              <label className="font-semibold block mb-2">Tìm kiếm</label>
              <input
                type="text"
                placeholder="Nhập tên sản phẩm..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg bg-gray-50 focus:ring-2 focus:ring-blue-600"
              />
            </div>

            {/* PRICE RANGE */}
            <div>
              <label className="font-semibold block mb-2">Giá (VNĐ)</label>

              <div className="flex items-center gap-3">
                <input
                  type="number"
                  placeholder="Tối thiểu"
                  value={priceMin}
                  onChange={(e) => setPriceMin(e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg bg-gray-50"
                />
                <span>-</span>
                <input
                  type="number"
                  placeholder="Tối đa"
                  value={priceMax}
                  onChange={(e) => setPriceMax(e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg bg-gray-50"
                />
              </div>
            </div>

            {/* SORT */}
            <div>
              <label className="font-semibold block mb-2">Sắp xếp</label>
              <select
                value={sortOption}
                onChange={(e) => setSortOption(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg bg-gray-50 focus:ring-2 focus:ring-blue-600"
              >
                <option value="default">Mặc định (mới nhất từ BE)</option>
                <option value="low">Giá thấp → cao</option>
                <option value="high">Giá cao → thấp</option>
                <option value="newest">Sản phẩm mới nhất (FE)</option>
              </select>
            </div>
          </div>
        </aside>

        {/* ========== PRODUCT GRID ========== */}
        <div className="md:col-span-3">
          {!loading && listings.length === 0 && (
            <p className="text-gray-500 italic mb-4">Không tìm thấy sản phẩm phù hợp.</p>
          )}

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
            {listings.map((product) => (
              <Link
                key={product.id}
                to={`/company/${product.companySlug}/product/${product.id}`}
                className="bg-white rounded-lg shadow hover:shadow-lg overflow-hidden transition"
              >
                <div className="h-48 bg-gray-200">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover hover:scale-105 transition-transform"
                  />
                </div>

                <div className="p-4">
                  <h4 className="font-semibold text-gray-900 text-sm mb-1 line-clamp-2">
                    {product.name}
                  </h4>
                  <p className="text-blue-600 font-bold text-sm">{product.priceLabel}</p>
                </div>
              </Link>
            ))}
          </div>

          {/* PAGINATION */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center mt-10 gap-3">
              <button
                onClick={() => setCurrentPage((p) => (p > 1 ? p - 1 : p))}
                className="p-2 rounded-lg hover:bg-gray-100 disabled:opacity-40"
                disabled={currentPage <= 1}
              >
                <ChevronLeft size={20} />
              </button>

              {pageList.map((page, index) => (
                <button
                  key={index}
                  disabled={page === "..."}
                  onClick={() => typeof page === "number" && setCurrentPage(page)}
                  className={`w-8 h-8 rounded-lg font-medium transition ${
                    page === currentPage
                      ? "bg-blue-600 text-white"
                      : "hover:bg-gray-100 text-gray-800"
                  }`}
                >
                  {page}
                </button>
              ))}

              <button
                onClick={() => setCurrentPage((p) => (p < totalPages ? p + 1 : p))}
                className="p-2 rounded-lg hover:bg-gray-100 disabled:opacity-40"
                disabled={currentPage >= totalPages}
              >
                <ChevronRight size={20} />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AllProductsPage;
