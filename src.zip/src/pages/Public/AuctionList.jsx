import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const AuctionList = () => {
  const [auctions, setAuctions] = useState([]);
  const [filter, setFilter] = useState("all"); // all | active | ended
  const [loading, setLoading] = useState(true);

  // ⭐ Gọi API backend /api/discovery/auctions
  useEffect(() => {
    const fetchAuctions = async () => {
      try {
        setLoading(true);

        const res = await auctionApi.getAll();

        if (res?.status === "success" && Array.isArray(res.data)) {
          const mapped = res.data.map((item) => ({
            id: item.id,
            title: item.title,
            image: item.image || "/placeholder.png",
            price: Number(item.start_price || 0),
            endsAt: item.ends_at,
          }));

          setAuctions(mapped);
        } else {
          setAuctions([]);
        }
      } catch (err) {
        console.error("Không thể tải đấu giá:", err);
        setAuctions([]);
      } finally {
        setLoading(false);
      }
    };

    fetchAuctions();
  }, []);

  // ⭐ Lọc trạng thái phiên đấu giá
  const now = Date.now();
  const filteredAuctions = auctions.filter((item) => {
    const end = new Date(item.endsAt).getTime();
    if (filter === "active") return end > now;
    if (filter === "ended") return end <= now;
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-10">
      {/* HEADER */}
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-3xl font-extrabold">Danh sách đấu giá</h2>

        <Link
          to="/auction/create"
          className="px-4 py-2 bg-indigo-600 text-white rounded-lg shadow hover:bg-indigo-700 transition"
        >
          + Đăng sản phẩm đấu giá
        </Link>
      </div>

      {/* ⭐ Bộ lọc */}
      <div className="flex gap-3 mb-8">
        {["all", "active", "ended"].map((key) => (
          <button
            key={key}
            onClick={() => setFilter(key)}
            className={`px-4 py-2 rounded-lg border ${
              filter === key
                ? key === "active"
                  ? "bg-green-600 text-white"
                  : key === "ended"
                    ? "bg-red-600 text-white"
                    : "bg-indigo-600 text-white"
                : "bg-white text-gray-700 hover:bg-gray-50"
            }`}
          >
            {key === "all" && "Tất cả"}
            {key === "active" && "Đang diễn ra"}
            {key === "ended" && "Đã kết thúc"}
          </button>
        ))}
      </div>

      {/* LOADING */}
      {loading && <p className="text-center text-gray-500">Đang tải dữ liệu...</p>}

      {/* GRID LIST */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {!loading &&
          filteredAuctions.map((item) => {
            const isEnded = new Date(item.endsAt).getTime() <= now;

            return (
              <Link
                key={item.id}
                to={`/auction/${item.id}`}
                className="bg-white rounded-xl shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-300 relative"
              >
                {isEnded && (
                  <div className="absolute inset-0 bg-black/50 text-white flex items-center justify-center rounded-xl text-sm font-semibold">
                    Đã kết thúc
                  </div>
                )}

                <img
                  src={item.image}
                  alt={item.title}
                  className={`h-36 w-full object-cover rounded-t-xl ${isEnded ? "opacity-60" : ""}`}
                />

                <div className="p-4">
                  <h3 className="font-semibold text-gray-800 text-sm line-clamp-2">{item.title}</h3>

                  <p className="text-indigo-600 font-bold mt-2 text-base">
                    ₫{item.price.toLocaleString("vi-VN")}
                  </p>
                </div>
              </Link>
            );
          })}
      </div>

      {/* EMPTY */}
      {!loading && filteredAuctions.length === 0 && (
        <p className="text-center text-gray-500 mt-10">Chưa có dữ liệu đấu giá.</p>
      )}
    </div>
  );
};

export default AuctionList;
