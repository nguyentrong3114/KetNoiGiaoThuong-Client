import ListingForm from "../../components/Company/ListingForm";

const CompanyPostPage = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <ListingForm />
    </div>
  );
};

export default CompanyPostPage;
