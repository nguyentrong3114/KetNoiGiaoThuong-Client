import AppRoute from './routes/AppRoute'
import './App.css'

function App() {
  return <AppRoute />
}

export default App
